#!/bin/bash

postgresVolume="./Docker/postgres/volume"
if ! [[ -d "$postgresVolume" ]]; then
    mkdir ${postgresVolume}
    chmod 777 ${postgresVolume}
fi

sudo docker-compose down
sudo docker-compose up -d --build --force-recreate
